package de.mjuergensen.unzen.phillip.LizenzManager;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class AddDataClass {

	public static void AddData(String programNameValue, String ownerValue, String notesValue, String serialNumberValue) {
		if(notesValue.trim().isEmpty())
		{
			notesValue = "Keine Angabe";
		}
		if(serialNumberValue.trim().isEmpty())
		{
			serialNumberValue = "Keine Angabe";
		}
			try {
				String workDir = System.getProperty("user.dir");
				Connection connection = DriverManager.getConnection("jdbc:sqlite:"+workDir+"/Lizenzen.db");
				Statement statement = connection.createStatement();
				String sql = "INSERT INTO LICENSE (PROGRAM, OWNER, NOTES, SERIALNUMBER) VALUES ("+"'"+programNameValue+"'"+","+"'"+ownerValue+"'"+","+"'"+notesValue+"'"+","+"'"+serialNumberValue+"'"+");";
				statement.execute(sql);
				
				JOptionPane message = new JOptionPane();
				message.showOptionDialog(null, "Daten wurden eingefügt", "Fehler!",
					 JOptionPane.DEFAULT_OPTION,
					 JOptionPane.INFORMATION_MESSAGE,
					 null, null, message);
				
			} catch (Exception e) {
				JOptionPane message = new JOptionPane();
				message.showOptionDialog(null, e, "Fehler!",
						JOptionPane.DEFAULT_OPTION,
						JOptionPane.ERROR_MESSAGE, 
						null, null, message);
				return;
			}
	}
}

package de.mjuergensen.unzen.phillip.LizenzManager;

import java.sql.*;
import java.io.*;
import javax.swing.*;

public class CreateDBClass {

	public static void CreateDatabase()
	{
		String workDir = System.getProperty("user.dir");
		File file = new File(workDir+"/Lizenzen.db");
		if(file.exists())
		{
			JOptionPane message = new JOptionPane();
			JOptionPane.showOptionDialog(null, "Datenbank schon vorhanden!", "Fehler!", JOptionPane.DEFAULT_OPTION,
					JOptionPane.ERROR_MESSAGE, null, null, message);
		} else {
			try
			{
				Class.forName("org.sqlite.JDBC");
				Connection connection = DriverManager.getConnection("jdbc:sqlite:"+workDir+"/Lizenzen.db");
				Statement statement = connection.createStatement();
				try 
				{
					statement.execute("CREATE TABLE LICENSE (ID INTEGER PRIMARY KEY AUTOINCREMENT, PROGRAM TEXT, OWNER TEXT, NOTES TEXT, SERIALNUMBER TEXT);");
				} catch (Exception ee) {
					JOptionPane message = new JOptionPane();
					message.showOptionDialog(null, ee.getStackTrace(), "Fehler!",
							JOptionPane.ERROR_MESSAGE,
							JOptionPane.DEFAULT_OPTION, null, null, message);
							file.deleteOnExit();
					return;
				}
				if (file.exists())
				{
					JOptionPane message = new JOptionPane();
					JOptionPane.showOptionDialog(null, "Datenbank wurde Erstellt!", "Erfolgreich!",
							JOptionPane.DEFAULT_OPTION,
							JOptionPane.INFORMATION_MESSAGE,
							null, null, message);
				}
			} catch (Exception e) {
				JOptionPane message = new JOptionPane();
				JOptionPane.showOptionDialog(null, e.getStackTrace(), "Fehler!",
						JOptionPane.DEFAULT_OPTION,
						JOptionPane.ERROR_MESSAGE,
						null, null, message);
			}
		}
	}
}
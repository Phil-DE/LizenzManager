package de.mjuergensen.unzen.phillip.LizenzManager;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.*;


public class LizenzManager {

	public static void main(String[] args) {
		String outputMessage = "";
		JTextField textboxProgrammName = new JTextField(1);
		JTextField textboxOwner = new JTextField(1);
		JTextField textboxNotes = new JTextField(1);
		JTextField textboxSerialNumber = new JTextField(1);
		JTextField textboxID = new JTextField(1);
		JTextField textboxColumn = new JTextField(1);
		JTextField textboxNewData = new JTextField(1);
		JTextField textboxDeleteID = new JTextField(1);
		JRadioButton onlyView = new JRadioButton("Daten anzeigen");
		JRadioButton toTXT = new JRadioButton("Zu .txt");
		JRadioButton toXLSX = new JRadioButton("Zu .xlsx");

		
//				### Erstellung und Design des GUI ###
		JFrame fenster = new JFrame();
		fenster.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		fenster.setTitle("LizenzManager - Version 1.0");
		fenster.setSize(960,470);
		fenster.setResizable(false);
		fenster.setLocation(50,50);
//##########################################################################
		JLabel header = new JLabel();
		header.setText("LizenzManager - SQLite3");
		header.setFont(new Font("Arial", Font.BOLD, 30));
		header.setHorizontalAlignment(JLabel.CENTER);
		header.setVerticalAlignment(JLabel.TOP);
		
		JButton buttonCreateDB = new JButton("Erstelle Datenbank");
		buttonCreateDB.setBounds(10, 400, 180, 30);
		buttonCreateDB.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0)
			{
				CreateDBClass.CreateDatabase();
			}
		});
		JButton buttonAddData = new JButton("Daten hinzufügen");
		buttonAddData.setBounds(200, 400, 180, 30);
		buttonAddData.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String programName = textboxProgrammName.getText();
				String owner = textboxOwner.getText();
				String notes = textboxNotes.getText();
				String serialNumber = textboxSerialNumber.getText();
				if(programName.trim().isEmpty() | owner.trim().isEmpty())
				{
					JOptionPane message = new JOptionPane();
					message.showOptionDialog(null, "Bitte überprüfen ob Programm & LizenzInhaber angegeben ist.", "Fehler!",
							JOptionPane.DEFAULT_OPTION,
							JOptionPane.ERROR_MESSAGE,
							null, null, "");
							return;
				} else {
					AddDataClass.AddData(programName, owner, notes, serialNumber);
					textboxProgrammName.setText("");
					textboxOwner.setText("");
					textboxNotes.setText("");
					textboxSerialNumber.setText("");
				}				
			}
		});
		JButton buttonEditData = new JButton("Ändere Daten");
		buttonEditData.setBounds(390, 400, 180, 30);
		JButton buttonRemoveData = new JButton("Entferne Daten");
		buttonRemoveData.setBounds(580, 400, 180, 30);
		JButton buttonViewData = new JButton("Exportiere Daten");
		buttonViewData.setBounds(770, 400, 180, 30);
		
		// Füge Daten hinzu
		JLabel labelProgramName = new JLabel("Lizenz für");
		labelProgramName.setBounds(200, 50, 180, 30);
		textboxProgrammName.setBounds(200, 80, 180, 30);
		
		JLabel labelOwnerName = new JLabel("Installiert auf");
		labelOwnerName.setBounds(200, 130, 180, 30);
		textboxOwner.setBounds(200, 160, 180, 30);
		
		JLabel labelNotes = new JLabel("Bemerkungen (Optional)");
		labelNotes.setBounds(200, 210, 180, 30);
		textboxNotes.setBounds(200, 240, 180, 30);
		
		JLabel labelSerialNumber = new JLabel("Seriennummer (Optional)");
		labelSerialNumber.setBounds(200, 290, 180, 30);
		textboxSerialNumber.setBounds(200, 320, 180, 30);
		
		//Ändere Daten
		JLabel labelID = new JLabel("ID");
		labelID.setBounds(390, 50, 180, 30);
		textboxID.setBounds(390, 80, 180, 30);
		
		JLabel labelColumn = new JLabel("Kategorie");
		labelColumn.setBounds(390, 130, 180, 30);
		textboxColumn.setBounds(390, 160, 180, 30);
		
		JLabel labelNewData = new JLabel("Neuer Eintrag");
		labelNewData.setBounds(390, 210, 180, 30);
		textboxNewData.setBounds(390, 240, 180, 30);
		
		// Lösche Daten
		JLabel labelDeleteID = new JLabel("ID");
		labelDeleteID.setBounds(580, 50, 180, 30);
		textboxDeleteID.setBounds(580, 80, 180, 30);
		
		//Exportiere Daten
		JLabel labelExport = new JLabel("Exportieren als");
		labelExport.setBounds(780, 50, 180, 30);
		onlyView.setBounds(780, 80, 180, 30);
		toTXT.setBounds(780, 110, 180, 30);
		toXLSX.setBounds(780, 140, 180, 30);
		
//##########################################################################
		fenster.add(labelProgramName);
		fenster.add(textboxID);
		fenster.add(labelExport);
		fenster.add(onlyView);
		fenster.add(textboxDeleteID);
		fenster.add(labelDeleteID);
		fenster.add(toTXT);
		fenster.add(toXLSX);
		fenster.add(textboxNewData);
		fenster.add(textboxColumn);
		fenster.add(labelColumn);
		fenster.add(labelNewData);
		fenster.add(labelID);
		fenster.add(textboxSerialNumber);
		fenster.add(labelSerialNumber);
		fenster.add(textboxNotes);
		fenster.add(labelOwnerName);
		fenster.add(textboxProgrammName);
		fenster.add(textboxOwner);
		fenster.add(buttonEditData);
		fenster.add(buttonCreateDB);
		fenster.add(buttonAddData);
		fenster.add(buttonRemoveData);
		fenster.add(buttonViewData);
		fenster.add(labelNotes);
		
		fenster.add(header);
		fenster.setVisible(true);
		
	}
	public String getDataFromTextbox()
	{
		return "";
	}

}
